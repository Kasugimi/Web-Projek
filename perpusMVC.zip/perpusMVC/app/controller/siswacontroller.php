<?php
require_once 'app/models/BukuModel.php';
require_once 'app/models/PinjamModel.php';

class SiswaController {
    public function __construct() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'siswa') {
            header("Location: index.php?controller=auth&action=login");
            exit;
        }
    }

    public function dashboard() {
        // highlight di dashboard
        $bukuModel = new BukuModel();
        $data_highlight = $bukuModel->getBukuHighlight();

        require_once 'app/views/siswa/dashboard.php';
    }

    // Katalog & Cari Buku
    public function katalog() {
        $bukuModel = new BukuModel();
        
        if (isset($_GET['cari'])) {
            $data_buku = $bukuModel->cariBuku($_GET['cari']);
        } else {
            $data_buku = $bukuModel->getAllBuku();
        }
        
        require_once 'app/views/siswa/katalog.php';
    }

// Proses Pinjam Saja (Sudah Diperbaiki)
    public function pinjam() {
        if (isset($_GET['id_buku'])) {
            $id_buku = $_GET['id_buku'];
            
            // Cek apakah ID User benar-benar ada di sesi login
            if (!isset($_SESSION['user']['id_user'])) {
                die("GAGAL PINJAM: ID User tidak terbaca di Session. Coba logout dan login kembali.");
            }
            $id_user = $_SESSION['user']['id_user'];
            
            $pinjamModel = new PinjamModel();

            // Langsung eksekusi pinjamBuku (stok sudah otomatis dikurangi di dalam fungsi ini)
            $simpan = $pinjamModel->pinjamBuku($id_user, $id_buku);
            
            if ($simpan) {
                echo "<script>alert('Berhasil meminjam buku! Silakan ambil di meja Admin.'); window.location='index.php?controller=siswa&action=riwayat';</script>";
            } else {
                echo "<script>alert('Gagal! Terjadi kesalahan pada database.'); window.location='index.php?controller=siswa&action=katalog';</script>";
            }
        }
    }
    
    // Halaman Riwayat Saja (Fungsi kembalikan sudah dihapus total)
    public function riwayat() {
        $pinjamModel = new PinjamModel();
        if (isset($_GET['cari'])) {
            $data_riwayat = $pinjamModel->cariRiwayatSiswa($_SESSION['user']['id_user'], $_GET['cari']);
        } else {
            $data_riwayat = $pinjamModel->getRiwayatSiswa($_SESSION['user']['id_user']);
        }
        
        require_once 'app/views/siswa/riwayat.php';
    }

    // =========================================================
    // FUNGSI UNTUK MENAMPILKAN DETAIL BUKU SAJA (TIDAK ADA PROSES PINJAM)
    // =========================================================
    public function detail_buku() {
        if (isset($_GET['id'])) {
            $id_buku = $_GET['id'];
            
            // Panggil model buku untuk ambil data
            require_once __DIR__ . '/../models/BukuModel.php';
            $bukuModel = new BukuModel();
            
            // Ambil data buku berdasarkan ID yang diklik
            $buku = $bukuModel->getBukuById($id_buku);

            // Tampilkan ke halaman detail
            require_once __DIR__ . '/../views/siswa/detail_buku.php';
        } else {
            // Jika tidak ada ID, kembalikan ke dashboard
            header("Location: index.php?controller=siswa&action=dashboard");
        }
    }
}
?>