<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Peminjaman</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">

    <div class="container mt-5">
        
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold text-primary">📋 Riwayat Peminjaman</h3>
            <a href="index.php?controller=siswa&action=dashboard" class="btn btn-secondary">
                ⬅ Kembali ke Dashboard
            </a>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="" class="d-flex gap-2">
                    <input type="hidden" name="controller" value="siswa">
                    <input type="hidden" name="action" value="riwayat">
                    <input type="text" name="cari" class="form-control" placeholder="Cari judul buku..." value="<?= isset($_GET['cari']) ? $_GET['cari'] : '' ?>">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>
            </div>
        </div>

        <div class="alert alert-info shadow-sm mb-4">
            💡 <b>Informasi:</b> Untuk mengembalikan buku, silakan bawa dan serahkan buku fisik kepada <b>Petugas Perpustakaan</b>.
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0 align-middle">
                        <thead class="table-dark text-center">
                            <tr>
                                <th width="5%" class="p-3">No</th>
                                <th class="p-3 text-start">Judul Buku</th>
                                <th class="p-3">Tanggal Pinjam</th>
                                <th class="p-3">Tanggal Kembali</th>
                                <th class="p-3">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            // PERBAIKAN 1: Menggunakan !empty() karena datanya berupa Array
                            if(!empty($data_riwayat)) {
                                // PERBAIKAN 2: Menggunakan foreach untuk mengulang isi Array
                                foreach($data_riwayat as $row) { 
                            ?>
                            <tr>
                                <td class="text-center fw-bold"><?= $no++; ?></td>
                                <td class="text-start fw-bold text-dark">
                                    📖 <?= $row['judul']; ?>
                                </td>
                                <td class="text-center">
                                    <?= date('d M Y', strtotime($row['tanggal_pinjam'])); ?>
                                </td>
                                <td class="text-center">
                                    <?php if($row['tanggal_kembali'] && $row['tanggal_kembali'] != '0000-00-00') { ?>
                                        <span class="text-success fw-bold">
                                            <?= date('d M Y', strtotime($row['tanggal_kembali'])); ?>
                                        </span>
                                    <?php } else { ?>
                                        <span class="text-muted">-</span>
                                    <?php } ?>
                                </td>
                                <td class="text-center">
                                    <?php if($row['status'] == 'dipinjam') { ?>
                                        <span class="badge bg-warning text-dark px-3 py-2 rounded-pill">
                                            ⏳ Sedang Dipinjam
                                        </span>
                                    <?php } else { ?>
                                        <span class="badge bg-success px-3 py-2 rounded-pill">
                                            ✅ Dikembalikan
                                        </span>
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php } 
                            } else { ?>
                                <tr>
                                    <td colspan="5" class="text-center p-5 text-muted">
                                        <h4 style="font-size: 50px;">📂</h4>
                                        <h5>Kamu belum pernah meminjam buku.</h5>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</body>
</html>
