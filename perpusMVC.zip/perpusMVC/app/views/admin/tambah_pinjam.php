<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Peminjaman Buku</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
    <style>
        /* Sedikit styling tambahan agar Select2 tingginya pas dengan Bootstrap */
        .select2-container .select2-selection--single {
            height: 38px;
            border: 1px solid #ced4da;
            border-radius: 0.375rem;
            padding: 4px 0px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-sm col-md-6 mx-auto border-0">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Form Peminjaman Buku</h5>
            </div>
            <div class="card-body">
                <form action="index.php?controller=admin&action=tambah_pinjam" method="POST">
                    
                    <div class="mb-3">
                        <label class="fw-bold">Pilih Peminjam</label>
                        <select name="id_user" class="form-select pilih-dengan-search" required>
                            <option value="">-- Ketik atau Pilih Anggota --</option>
                            <?php foreach($data_user as $u): ?>
                                <?php if($u['role'] == 'siswa'): ?>
                                    <option value="<?= $u['id_user'] ?>">
                                        <?= $u['nama_lengkap'] ?>
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold">Pilih Buku</label>
                        <select name="id_buku" class="form-select pilih-dengan-search" required>
                            <option value="">-- Ketik Judul Buku --</option>
                            <?php foreach($data_buku as $b): ?>
                                <option value="<?= $b['id_buku'] ?>" <?= ($b['stok'] <= 0) ? 'disabled' : '' ?>>
                                    <?= $b['judul'] ?> (Sisa Stok: <?= $b['stok'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="fw-bold">Tanggal Pinjam</label>
                        <input type="date" name="tanggal_pinjam" class="form-control text-muted" style="background-color: #e9ecef; cursor: not-allowed;" value="<?= date('Y-m-d') ?>" readonly>
                        <small class="text-danger mt-1 d-block">*Tanggal peminjaman otomatis terekam hari ini dan tidak dapat diubah.</small>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="index.php?controller=admin&action=kelola_pinjam" class="btn btn-secondary">Kembali</a>
                        <button type="submit" name="simpan_pinjam" class="btn btn-success">Simpan & Pinjam</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <script>
        // Mengaktifkan fitur pencarian pada dropdown
        $(document).ready(function() {
            $('.pilih-dengan-search').select2({
                width: '100%' // Mengatur lebar penuh sesuai container
            });
        });
    </script>
</body>
</html>
