<?php
class Database {
    private $host = "localhost"; 
    private $user = "root";
    private $pass = ""; 
    private $db   = "db_perpustakaan_sekolah";
    
    public $koneksi;

    public function __construct() {
        // Tambahkan port 3306 (optional, tapi lebih aman di Android)
        $this->koneksi = mysqli_connect($this->host, $this->user, $this->pass, $this->db, 3306);
        
        if (!$this->koneksi) {
            die("Koneksi gagal: " . mysqli_connect_error());
        }
    }
}
?>
