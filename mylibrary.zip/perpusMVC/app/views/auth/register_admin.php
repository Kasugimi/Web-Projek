<!DOCTYPE html>
<html>
<head>
    <title>Daftar Admin Baru</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-dark"> <div class="container mt-5">
        <div class="card shadow-lg mx-auto" style="max-width: 500px;">
            <div class="card-header bg-danger text-white">
                <h4 class="text-center">REGISTRASI ADMIN</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-warning text-center">
                    Area Terbatas! Masukkan Kode Keamanan.
                </div>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label>Kode Keamanan (Token)</label>
                        <input type="password" name="kode_rahasia" class="form-control" placeholder="Masukkan Kode Rahasia..." required>
                    </div>
                    
                    <hr>

                    <div class="mb-3">
                        <label>Nama Lengkap Admin</label>
                        <input type="text" name="nama_lengkap" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Username Baru</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>

                    <button type="submit" name="daftar_admin" class="btn btn-danger w-100">Daftar Sebagai Admin</button>
                </form>
                
                <div class="text-center mt-3">
                    <a href="index.php?controller=auth&action=login" class="text-secondary">Kembali ke Login</a>
                </div>
            </div>
        </div>
    </div>

</body>
</html>