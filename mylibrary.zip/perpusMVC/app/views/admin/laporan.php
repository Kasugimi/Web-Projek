<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Perpustakaan</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <style>
        .filter-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #dee2e6;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bg-light">

    <div class="container mt-5 mb-5">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h3 class="mb-0 fw-bold text-primary">📊 Laporan Peminjaman</h3>
                    <a href="index.php?controller=admin&action=dashboard" class="btn btn-secondary">
                        ⬅ Kembali ke Dashboard
                    </a>
                </div>
            </div>

            <div class="card-body">
                
                <form method="GET" action="index.php" class="filter-box">
                    <input type="hidden" name="controller" value="admin">
                    <input type="hidden" name="action" value="laporan">
                    
                    <div class="row align-items-end">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Dari Tanggal:</label>
                            <input type="date" name="tgl_awal" class="form-control" value="<?= isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : '' ?>" required>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Sampai Tanggal:</label>
                            <input type="date" name="tgl_akhir" class="form-control" value="<?= isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : '' ?>" required>
                        </div>
                        
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100">🔍 Tampilkan Data</button>
                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover align-middle">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>No</th>
                                <th>Nama Peminjam</th>
                                <th>Judul Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Status</th>
                                <th width="150">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            // PERBAIKAN: Menggunakan !empty() karena data berupa Array
                            if (!empty($data_laporan)) {
                                // PERBAIKAN: Menggunakan foreach untuk looping data Array
                                foreach($data_laporan as $row) { ?>
                                <tr>
                                    <td class="text-center"><?= $no++; ?></td>
                                    <td><?= $row['nama_lengkap']; ?></td>
                                    <td><?= $row['judul']; ?></td>
                                    <td class="text-center"><?= date('d-m-Y', strtotime($row['tanggal_pinjam'])); ?></td>
                                    <td class="text-center">
                                        <?= ($row['tanggal_kembali'] && $row['tanggal_kembali'] != '0000-00-00') ? date('d-m-Y', strtotime($row['tanggal_kembali'])) : '-'; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($row['status'] == 'dipinjam') { ?>
                                            <span class="badge bg-danger">Dipinjam</span>
                                        <?php } else { ?>
                                            <span class="badge bg-success">Kembali</span>
                                        <?php } ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="index.php?controller=admin&action=edit_transaksi&id=<?= $row['id_transaksi']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <a href="index.php?controller=admin&action=hapus_transaksi&id=<?= $row['id_transaksi']; ?>" 
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Hapus riwayat transaksi ini?')">Hapus</a>
                                    </td>
                                </tr>
                                <?php } 
                            } else { ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4 text-muted">
                                        <h5>Tidak ada data.</h5>
                                        <p class="mb-0">Silakan pilih rentang tanggal lain atau tunggu peminjaman baru.</p>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
            <div class="card-footer bg-white text-end text-muted">
                <small>Data per: <?= date('d-m-Y H:i'); ?></small>
            </div>
        </div>
    </div>

</body>
</html>
