<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Data Anggota</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-primary">👥 Data Anggota</h3>
                <p class="text-muted mb-0">Daftar siswa yang terdaftar di perpustakaan.</p>
            </div>
            <a href="index.php?controller=admin&action=dashboard" class="btn btn-secondary">
                ⬅ Kembali ke Dashboard
            </a>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0 align-middle">
                        <thead class="table-dark text-center">
                            <tr>
                                <th width="5%" class="p-3">No</th>
                                <th class="p-3 text-start">Nama Lengkap</th>
                                <th class="p-3">Username</th>
                                <th class="p-3">Role</th>
                                <th width="20%" class="p-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            // Cek data
                            if (mysqli_num_rows($data_siswa) > 0) {
                                while($row = mysqli_fetch_assoc($data_siswa)) { ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= $no++; ?></td>
                                    <td class="text-start">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-light rounded-circle text-primary d-flex justify-content-center align-items-center me-3" style="width: 40px; height: 40px; font-weight: bold;">
                                                <?= strtoupper(substr($row['nama_lengkap'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <span class="fw-bold d-block"><?= $row['nama_lengkap']; ?></span>
                                                <small class="text-muted">ID: <?= $row['id_user']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="text-muted">@<?= $row['username']; ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-info text-dark rounded-pill px-3">
                                            <?= strtoupper($row['role']); ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="index.php?controller=admin&action=edit_anggota&id=<?= $row['id_user']; ?>" 
                                               class="btn btn-warning btn-sm text-white" 
                                               title="Edit Data">
                                                ✏ Edit
                                            </a>
                                            <a href="index.php?controller=admin&action=kelola_anggota&hapus_id=<?= $row['id_user']; ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('PERINGATAN!\n\nMenghapus siswa ini akan menghapus SEMUA riwayat peminjamannya juga.\n\nYakin ingin melanjutkan?')"
                                               title="Hapus Permanen">
                                                🗑 Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php } 
                            } else { ?>
                                <tr>
                                    <td colspan="5" class="text-center p-5 text-muted">
                                        <h5>Belum ada data siswa.</h5>
                                        <p>Silakan tunggu siswa mendaftar.</p>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white py-3">
                <small class="text-muted">Total Siswa: <b><?= mysqli_num_rows($data_siswa); ?></b> orang</small>
            </div>
        </div>
    </div>

</body>
</html>