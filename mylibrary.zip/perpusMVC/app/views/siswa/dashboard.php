<!DOCTYPE html>
<html lang="id">
<head>
    <title>Dashboard Siswa</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <style>
        /* jumbotron */
        .hero-section {
            background: linear-gradient(45deg, #1d2671 0%, #c33764 100%); /* Warna Gradasi Ungu-Pink Keren */
            color: white;
            border-radius: 15px;
            padding: 40px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        
        /* Efek lingkaran transparan hiasan */
        .hero-section::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
        }

        .highlight-card {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(5px);
            border-radius: 10px;
            padding: 20px;
            border: 1px solid rgba(255,255,255,0.3);
        }
        
        .hover-card:hover {
            transform: translateY(-5px);
            transition: 0.3s;
        }
    </style>
</head>
<body class="bg-light">
    
    <nav class="navbar navbar-dark bg-dark mb-4 shadow-sm">
        <div class="container">
            <span class="navbar-brand mb-0 h1">🎓 MY LIBRARY</span>
            <div class="d-flex align-items-center text-white">
                <small class="me-3">Halo, <?= $_SESSION['user']['nama_lengkap']; ?></small>
                <a href="index.php?controller=auth&action=logout" class="btn btn-outline-light btn-sm" onclick="return confirm('Keluar?')">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        
        <div class="hero-section mb-5">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <h1 class="fw-bold">Selamat Datang! 👋</h1>
                    <p class="lead">Temukan ribuan ilmu baru. Apa yang ingin kamu baca hari ini?</p>
                </div>
                
                <div class="col-md-5 d-none d-md-block">
                    <div id="bookCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php 
                            $active = "active";
                            while($buku = mysqli_fetch_assoc($data_highlight)) { 
                            ?>
                            <div class="carousel-item <?= $active; ?>">
                                <div class="highlight-card text-center">
                                    <div style="font-size: 50px;">📖</div>
                                    <h5 class="fw-bold mt-2"><?= $buku['judul']; ?></h5>
                                    <p class="mb-1 small">Oleh: <?= $buku['pengarang']; ?></p>
                                    <span class="badge bg-warning text-dark">Stok: <?= $buku['stok']; ?></span>
                                    <br>
                                    <a href="index.php?controller=siswa&action=pinjam&id_buku=<?= $buku['id_buku']; ?>" class="btn btn-sm btn-light mt-3">Pinjam Sekarang</a>
                                </div>
                            </div>
                            <?php 
                                $active = "";
                            } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <h4 class="mb-3 text-muted">Menu Akses Cepat</h4>
        <div class="row">
            <div class="col-md-6 mb-3">
                <a href="index.php?controller=siswa&action=katalog" class="text-decoration-none">
                    <div class="card h-100 shadow-sm border-0 bg-white hover-card">
                        <div class="card-body d-flex align-items-center p-4">
                            <div class="bg-primary text-white rounded-circle p-3 me-3 display-6">🔍</div>
                            <div>
                                <h4 class="text-dark mb-1">Cari Buku</h4>
                                <p class="text-muted mb-0 small">Telusuri koleksi lengkap perpustakaan.</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-6 mb-3">
                <a href="index.php?controller=siswa&action=riwayat" class="text-decoration-none">
                    <div class="card h-100 shadow-sm border-0 bg-white hover-card">
                        <div class="card-body d-flex align-items-center p-4">
                            <div class="bg-success text-white rounded-circle p-3 me-3 display-6">📋</div>
                            <div>
                                <h4 class="text-dark mb-1">Riwayat Saya</h4>
                                <p class="text-muted mb-0 small">Cek buku yang sedang dipinjam.</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>

    </div>

    <script src="public/js/bootstrap.bundle.min.js"></script>

</body>
</html>