<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Buku</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5 mb-5">
        <div class="card shadow-sm border-0 col-md-6 mx-auto">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📖 Informasi Detail Buku</h5>
            </div>
            <div class="card-body">
                
                <h3 class="fw-bold text-center text-primary mb-4"><?= $buku['judul']; ?></h3>
                
                <table class="table table-borderless">
                    <tr>
                        <th width="30%">Pengarang</th>
                        <td>: <?= isset($buku['pengarang']) ? $buku['pengarang'] : '-'; ?></td>
                    </tr>
                    <tr>
                        <th>Sisa Stok</th>
                        <td>: 
                            <?php if(isset($buku['stok']) && $buku['stok'] > 0) { ?>
                                <span class="badge bg-success"><?= $buku['stok']; ?> Buku Tersedia</span>
                            <?php } else { ?>
                                <span class="badge bg-danger">Stok Habis</span>
                            <?php } ?>
                        </td>
                    </tr>
                </table>

                <div class="d-grid gap-2 mt-4">
                    <?php if(isset($buku['stok']) && $buku['stok'] > 0) { ?>
                        <button type="button" class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#modalPinjam">
                            Pinjam Buku Ini
                        </button>
                    <?php } else { ?>
                        <button class="btn btn-secondary btn-lg" disabled>Buku Sedang Kosong</button>
                    <?php } ?>
                    
                    <a href="index.php?controller=siswa&action=katalog" class="btn btn-outline-secondary w-100">⬅ Kembali ke Daftar Buku</a>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modalPinjam" tabindex="-1" aria-labelledby="modalPinjamLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalPinjamLabel">Konfirmasi Peminjaman</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center p-4">
                    <p class="mb-1">Apakah kamu yakin ingin meminjam buku:</p>
                    <h4 class="fw-bold text-primary mb-3"><?= $buku['judul']; ?></h4>
                    <div class="alert alert-warning small mb-0">
                        Pastikan kamu segera menemui Petugas Perpustakaan untuk mengambil fisik buku ini setelah menekan tombol konfirmasi.
                    </div>
                </div>
                <div class="modal-footer justify-content-center bg-light">
                    <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Batal</button>
                    <a href="index.php?controller=siswa&action=pinjam&id_buku=<?= $buku['id_buku']; ?>" class="btn btn-success px-4">Ya, Pinjam Sekarang</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>