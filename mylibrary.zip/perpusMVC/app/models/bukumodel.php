<?php
class BukuModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    // Mengambil semua data buku
    public function getAllBuku() {
        return mysqli_query($this->db->koneksi, "SELECT * FROM buku");
    }

    public function cariBuku($keyword) {
        // AMANKAN INPUTAN
        $keyword = mysqli_real_escape_string($this->db->koneksi, $keyword);
        $query = "SELECT * FROM buku WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%'";
        return mysqli_query($this->db->koneksi, $query);
    }

    public function tambahBuku($data) {
        // Bersihkan semua data array $_POST langsung
        $judul = mysqli_real_escape_string($this->db->koneksi, $data['judul']);
        $pengarang = mysqli_real_escape_string($this->db->koneksi, $data['pengarang']);
        $penerbit = mysqli_real_escape_string($this->db->koneksi, $data['penerbit']);
        $stok = (int) $data['stok']; // Paksa jadi angka (integer)
        
        $query = "INSERT INTO buku VALUES (NULL, '$judul', '$pengarang', '$penerbit', '$stok')";
        return mysqli_query($this->db->koneksi, $query);
    }
    
  public function hapusBuku($id) {
    $id = mysqli_real_escape_string($this->db->koneksi, $id);
    mysqli_query($this->db->koneksi, "DELETE FROM pinjam WHERE id_buku='$id'");
    return mysqli_query($this->db->koneksi, "DELETE FROM buku WHERE id_buku='$id'");
}

    // Mengurangi stok saat dipinjam
    public function kurangiStok($id_buku) {
        return mysqli_query($this->db->koneksi, "UPDATE buku SET stok = stok - 1 WHERE id_buku='$id_buku' AND stok > 0");
    }

    // Menambah stok saat dikembalikan
    public function kembalikanStok($id_buku) {
        return mysqli_query($this->db->koneksi, "UPDATE buku SET stok = stok + 1 WHERE id_buku='$id_buku'");
    }
    // Ambil 1 data buku berdasarkan ID
    public function getBukuById($id) {
        $id = mysqli_real_escape_string($this->db->koneksi, $id);
        $query = "SELECT * FROM buku WHERE id_buku='$id'";
        $result = mysqli_query($this->db->koneksi, $query);
        return mysqli_fetch_assoc($result);
    }

    // Update Data Buku
    public function updateBuku($data) {
        $id = $data['id_buku'];
        $judul = mysqli_real_escape_string($this->db->koneksi, $data['judul']);
        $pengarang = mysqli_real_escape_string($this->db->koneksi, $data['pengarang']);
        $penerbit = mysqli_real_escape_string($this->db->koneksi, $data['penerbit']);
        $stok = (int) $data['stok'];

        $query = "UPDATE buku SET 
                  judul='$judul', 
                  pengarang='$pengarang', 
                  penerbit='$penerbit', 
                  stok='$stok' 
                  WHERE id_buku='$id'";
        
        return mysqli_query($this->db->koneksi, $query);
    }

    // Ambil 3 buku secara acak untuk Highlight Dashboard
    public function getBukuHighlight() {
        // akan mengacak urutan setiap kali refresh halaman 
        $query = "SELECT * FROM buku WHERE stok > 0 ORDER BY RAND() LIMIT 3";
        return mysqli_query($this->db->koneksi, $query);
    }
} 

?>
