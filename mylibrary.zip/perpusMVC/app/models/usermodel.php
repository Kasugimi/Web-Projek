<?php
class UserModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function checkLogin($username, $password) {
        // AMANKAN INPUTAN:
        $username = mysqli_real_escape_string($this->db->koneksi, $username);
        $password = mysqli_real_escape_string($this->db->koneksi, $password);
        
        // Baru diproses
        $pass = md5($password);
        $query = "SELECT * FROM users WHERE username='$username' AND password='$pass'";
        $result = mysqli_query($this->db->koneksi, $query);
        return mysqli_fetch_assoc($result);
    }

    // Register Siswa Baru
    public function tambahSiswa($data) {
        $nama = $data['nama_lengkap'];
        $username = $data['username'];
        $password = md5($data['password']);
        $role = 'siswa'; 

        $query = "INSERT INTO users (username, password, nama_lengkap, role) 
                  VALUES ('$username', '$password', '$nama', '$role')";
        
        return mysqli_query($this->db->koneksi, $query);
    }

    // Admin: Ambil semua data siswa
    public function getAllSiswa() {
        return mysqli_query($this->db->koneksi, "SELECT * FROM users WHERE role='siswa'");
    }

  public function hapusUser($id_user) {
    // 1. Amankan ID dari serangan SQL Injection
    $id = mysqli_real_escape_string($this->db->koneksi, $id_user);

    // 2. HAPUS RIWAYAT DULU (Gunakan nama tabel 'transaksi')
    // Ini penting agar tidak terjadi error Foreign Key
    mysqli_query($this->db->koneksi, "DELETE FROM transaksi WHERE id_user='$id'");

    // 3. BARU HAPUS USERNYA
    $query = "DELETE FROM users WHERE id_user='$id'";
    $result = mysqli_query($this->db->koneksi, $query);

    return $result;
}

    // Ambil data user berdasarkan ID
    public function getUserById($id) {
        $id = mysqli_real_escape_string($this->db->koneksi, $id);
        $query = "SELECT * FROM users WHERE id_user='$id'";
        $result = mysqli_query($this->db->koneksi, $query);
        return mysqli_fetch_assoc($result);
    }

    // Update Data User
    public function updateUser($data) {
        $id = $data['id_user'];
        $nama = mysqli_real_escape_string($this->db->koneksi, $data['nama_lengkap']);
        $username = mysqli_real_escape_string($this->db->koneksi, $data['username']);
        
        if (!empty($data['password'])) {
            $pass = md5($data['password']);
            $query = "UPDATE users SET nama_lengkap='$nama', username='$username', password='$pass' WHERE id_user='$id'";
        } else {
            $query = "UPDATE users SET nama_lengkap='$nama', username='$username' WHERE id_user='$id'";
        }

        return mysqli_query($this->db->koneksi, $query);
    }

    // Registrasi Khusus Admin
    public function tambahAdmin($data) {
        $nama = mysqli_real_escape_string($this->db->koneksi, $data['nama_lengkap']);
        $username = mysqli_real_escape_string($this->db->koneksi, $data['username']);
        $password = md5($data['password']);
        $role = 'admin';

        $query = "INSERT INTO users (username, password, nama_lengkap, role) 
                  VALUES ('$username', '$password', '$nama', '$role')";
        
        return mysqli_query($this->db->koneksi, $query);
    }

    // Fungsi untuk mengambil semua data pengguna (Admin & Siswa) untuk pilihan di form peminjaman
    public function getAllUser() {
        // Menggunakan koneksi aslimu dan tabel 'users'
        $query = "SELECT * FROM users";
        $result = mysqli_query($this->db->koneksi, $query);
        
        $data = [];
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
        }
        return $data;
    }
    
}
?>
