<?php
require_once 'app/models/UserModel.php';

class AuthController {
    
    // FUNGSI LOGIN
    public function login() {
        if (isset($_POST['submit'])) {
            $userModel = new UserModel();
            $user = $userModel->checkLogin($_POST['username'], $_POST['password']);

            if ($user) {
                $_SESSION['user'] = $user;
                if ($user['role'] == 'admin') {
                    header("Location: index.php?controller=admin&action=dashboard");
                } else {
                    // Redirect ke Dashboard Siswa
                    header("Location: index.php?controller=siswa&action=dashboard");
                }
            } else {
                echo "<script>alert('Login Gagal! Username atau Password salah.');</script>";
                require_once 'app/views/auth/login.php';
            }
        } else {
            require_once 'app/views/auth/login.php';
        }
    }

    // FUNGSI REGISTER
    public function register() {
        if (isset($_POST['daftar'])) {
            $userModel = new UserModel();
            $simpan = $userModel->tambahSiswa($_POST);

            if ($simpan) {
                echo "<script>alert('Pendaftaran Berhasil! Silakan Login.'); window.location='index.php?controller=auth&action=login';</script>";
            } else {
                echo "<script>alert('Pendaftaran Gagal.');</script>";
            }
        }
        // Tampilkan view register
        require_once 'app/views/auth/register.php';
    }

    public function logout() {
        session_destroy();
        header("Location: index.php?controller=auth&action=login");
    }

    // Action: Halaman Register Admin
    public function register_admin() {
        // Kode Rahasia agar tidak sembarang orang bisa daftar
        $KODE_RAHASIA = "ADMIN_SEKOLAH_2026"; 

        if (isset($_POST['daftar_admin'])) {
            $input_kode = $_POST['kode_rahasia'];

            // 1. Cek Kode Rahasia
            if ($input_kode === $KODE_RAHASIA) {
                $userModel = new UserModel();
                // 2. Simpan ke Database
                $simpan = $userModel->tambahAdmin($_POST);

                if ($simpan) {
                    echo "<script>alert('Sukses! Akun Admin berhasil dibuat. Silakan Login.'); window.location='index.php?controller=auth&action=login';</script>";
                } else {
                    echo "<script>alert('Gagal mendaftar (Username mungkin sudah ada).');</script>";
                }
            } else {
                echo "<script>alert('KODE RAHASIA SALAH! Anda tidak berhak mendaftar sebagai Admin.');</script>";
            }
        }
        
        // Tampilkan View
        require_once 'app/views/auth/register_admin.php';
    }

}
?>
